from flask import Flask
from flask_restful import Api

from resources.photo import PhotoResource, PhotoReview

app = Flask(__name__)

api = Api(app)


api.add_resource( PhotoResource , '/photo' )
api.add_resource( PhotoReview , '/review' )

if __name__ == '__main__':
    app.run()