from flask_restful import Resource
from flask import request
from datetime import datetime
from config import Config

# AWS의 여러 서비스들을 이용할 수 있는 파이썬 라이브러리
import boto3

class PhotoReview(Resource):
    
    def post(self) :

        # 사진이랑 내용은 필수다!
        
        print(request.files)
        print(request.form)
        # 변수에 뭐가 들어있는지 확인 필수 

        # if 'photo' not in request.files : 
        #     return {'result' : 'fail','error':'사진은 필수'}
        
        # if 'content' not in request.files : 
        #     return {'result' : 'fail','error':'내용은 필수'}
        
        if 'photo' not in request.files or 'content' not in request.files or 'rating' not in request.form :
            return {'result' : 'fail','error':'필수항목 확인'}, 400 


        file = request.files['photo']
        content = request.form['content']
        rating = request.form['rating'] 
        rating = int(rating)


        #### S3 저장코드는 동일 ####

        ### content와 image_url은 DB에 저장한다.

        # rating은 0부터 s까지인데, 이 값을 0~100사이의 값으로 변경하여,
        # 클라이언트한테 보내시오 

        rating = rating * 20


        
        return {'rating': rating}

class PhotoResource(Resource):

    def post(self) : 

        print(request.files)

        # 사진이 필수인 경우의 코드
        if 'photo' not in request.files : 
            return {'result' : 'fail','error':'파일없음'},400
        
        # 유저가 올린 파일을 변수로 만든다.
        file = request.files['photo']

        # 파일명을 유니크하게 만들어준다.

        current_time = datetime.now()
        print(current_time.isoformat().replace(':','_').replace('.','_')+'.jpg')
        
        new_filename = current_time.isoformat().replace(':','_').replace('.','_')+'.jpg'

        # 새로운 파일명으로, s3에 파일 업로드


        try :
            s3 = boto3.client('s3', aws_access_key_id = Config.AWS_ACCESS_KEY_ID,
                     aws_secret_access_key = Config.AWS_SECRET_ACCESS_KEY)
            
            s3.upload_fileobj(file, 
                              Config.S3_BUCKET,
                              new_filename,
                              ExtraArgs = {'ACL':'public-read' , 'ContentType':'image/jpeg'})
        except Exception as e :
            print(str(e))
            return{'result':'fail','error':str(e)}, 500
        
        # 위에서 저장한 사진의 URL 주소를 DB에 저장해야 한다!
        # URL 주소는 = 버킷명.S3주소/우리가만든파일명
        file_url =  Config.S3_BASE_URL + new_filename
        
        # 잘 되었으면 클레이언트에 데이터를 응답한다.
        return {'result':'success', 'file_url':file_url}

        
        


        return