class Config :
    AWS_ACCESS_KEY_ID = 'AKIAZTQXQZNSW4HO3CJY'
    AWS_SECRET_ACCESS_KEY = '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'
    S3_BUCKET = 'bong-img-test'
    S3_BASE_URL = 'http://' + S3_BUCKET + '.s3.amazonaws.com/'

    X_NAVER_CLIENT_ID = '24FVLhRzbTfFhyZf8Px4'
    X_NAVER_CLIENT_SECRET = 'isrdEwwt4H'